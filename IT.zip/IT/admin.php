<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>About-Us</title>
    <link rel="stylesheet" href="./style2.css">
    <link rel="stylesheet" type="text/css" href="source/bootstrap-3.3.6-dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="source/font-awesome-4.5.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="style/mystyle.css">
  </head>
<body>

<div class="header">
			<ul class="socialicon">
				<li><a href="#"><i class="fa fa-facebook"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter"></i></a></li>
				<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
				<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
			</ul>

			<ul class="givusacall">
				<li>Give us a call : +91 9019090292 </li>
			</ul>

      <ul class="logreg">

        <li><a href="index.html">Logout </a> </li>
        <li><a href="appoint.php"><span class="register">Appointments</span></a></li>
        <li><a href="adminfeed.php"><span class="register">Feedbacks</span></a></li>
      </ul>
</div>

<div class="feturedsection">
  <h1 class="text-center"><span class="bdots">&bullet;</span> E L E G A N T <span class="carstxt"> C A R - S P A </span>&bullet;</h1>
</div>




</body>
</html>
